<?php
echo "<div><center><h1>QUEM SOMOS</h1></center></div>";

?>