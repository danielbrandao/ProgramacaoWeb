<?php
echo "<div><center><h1>RODAPÉ DO SITE</h1></center></div>";

?>