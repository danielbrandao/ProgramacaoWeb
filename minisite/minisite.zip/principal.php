<?php

echo "<div><center><p><h3>CONTEÚDO 1 DO SITE</h3></center></div></p>

<div><center><p><h3>CONTEÚDO 2 DO SITE</h3></center></div></p>

<div><center><p><h3>CONTEÚDO 3 DO SITE</h3></center></div></p>";


?>