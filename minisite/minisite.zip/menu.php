<?php
echo "<div><center><h1>MENU DO SITE</h1></center>
</div>";
echo "<nav><center><a href='?pg=principal'>Home</a> | 
<a href='?pg=quemsomos'>Quem somos</a> | 
<a href='?pg=clientes'>Clientes</a> | 
<a href='?pg=contato'>Fale conosco</a> |
</div></center></nav>";

?>