<?php
echo "<div><center><h1>CONTATO</h1></center></div>";

?>